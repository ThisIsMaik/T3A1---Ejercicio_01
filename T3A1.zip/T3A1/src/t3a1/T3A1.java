package t3a1;

import java.util.Scanner;

public class T3A1 {

    public static void main(String[] args) {
        procesar();
    }
    
    public static void procesar(){
        Scanner scanner = new Scanner(System.in);
        Calificaciones calificaciones = new Calificaciones();
        
        System.out.print("Nombre: ");
        String nombre = scanner.nextLine();
        calificaciones.setNombre(nombre);
        
        System.out.print("Apellido Paterno: ");
        String apellidoPaterno = scanner.nextLine();
        calificaciones.setApellidoPaterno(apellidoPaterno);
        
        System.out.print("Apellido Materno: ");
        String apellidoMaterno = scanner.nextLine();
        calificaciones.setApellidoMaterno(apellidoMaterno);
        
        System.out.println("Grupo: ");
        String grupo = scanner.nextLine();
        calificaciones.setGrupo(grupo);
        
        System.out.println("Carrera: ");
        String carrera = scanner.nextLine();
        calificaciones.setCarrera(carrera);
        
        System.out.println("Asignatura: ");
        String nombreAsignatura = scanner.nextLine();
        calificaciones.setNombreAsignatura(nombreAsignatura);
        
        System.out.println("Asignatura 2: ");
        String nombreAsignatura2 = scanner.nextLine();
        calificaciones.setNombreAsignatura2(nombreAsignatura2);
        
        System.out.println("Calificacion: ");
        int calificacion2 = scanner.nextInt();
        calificaciones.setCalificacion(calificacion2);
        
        System.out.println("Calificacion 2: ");
        int calificacion = scanner.nextInt();
        calificaciones.setCalificacion2(calificacion);
        
        calificaciones.setPromedio(calificacion);
        
        System.out.println("Estudiante: " + calificaciones.getNombre());
        System.out.println("Grupo: " + calificaciones.getGrupo());
        System.out.println("Carrera: " + calificaciones.getCarrera());
        System.out.println("Asignatura: " + calificaciones.getNombreAsignatura());
        System.out.println("Calificacion: " + calificaciones.getCalificacion());
        System.out.println("Asignatura2: " + calificaciones.getNombreAsignatura2());
        System.out.println("Calificacion2: " + calificaciones.getCalificacion2());
        System.out.println("Promedio: " + calificaciones.getPromedio());

       
        
        
    }
    
}